package com.efarmer;
//hii by Akshay
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprEfarmerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprEfarmerApplication.class, args);
	}

}

